package pkg1libreria;
/**
 *
 * @author josue
 */
import java.sql.*;
import javax.swing.JOptionPane;
public class Conexion {
    private Connection con = null;
    private String db="libros";
    private String login="root";
    private String password="12345";
    private String url="jdbc:mariadb://localhost/"+db;
    
    public Connection Conect(){
        try{
            Class.forName("org.mariadb.jdbc.Driver");
            con=DriverManager.getConnection(url,login,password);
            if(con != null){
                //System.out.println("Conexión Establecida");
                JOptionPane.showMessageDialog(null,"Conexón Establecida");
            }
        }catch (ClassNotFoundException | SQLException e){
            //System.out.println("Error de conexión");
            JOptionPane.showMessageDialog(null, "Error de coneción \n"+e);
        }
        return con;
    }
}