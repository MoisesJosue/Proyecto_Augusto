package pkg1libreria;

/**
 *
 * @author josue
 */
public class ConexionFormulario extends javax.swing.JFrame {
    public ConexionFormulario() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        BttLista = new javax.swing.JButton();
        BttModificar = new javax.swing.JButton();
        BttVender = new javax.swing.JButton();
        BttReporte = new javax.swing.JButton();
        bttSalir = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        BttConectar = new javax.swing.JButton();
        BttInsertar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 255));
        jPanel1.setForeground(new java.awt.Color(51, 255, 51));
        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        BttLista.setBackground(new java.awt.Color(255, 0, 0));
        BttLista.setFont(new java.awt.Font("Lucida Handwriting", 1, 12)); // NOI18N
        BttLista.setForeground(new java.awt.Color(255, 255, 255));
        BttLista.setText("Ver Datos");
        BttLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BttListaActionPerformed(evt);
            }
        });

        BttModificar.setBackground(new java.awt.Color(255, 0, 0));
        BttModificar.setFont(new java.awt.Font("Lucida Handwriting", 1, 12)); // NOI18N
        BttModificar.setForeground(new java.awt.Color(255, 255, 255));
        BttModificar.setText("Modificaciones");
        BttModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BttModificarActionPerformed(evt);
            }
        });

        BttVender.setBackground(new java.awt.Color(255, 0, 0));
        BttVender.setFont(new java.awt.Font("Lucida Handwriting", 1, 12)); // NOI18N
        BttVender.setForeground(new java.awt.Color(255, 255, 255));
        BttVender.setText("Vender");

        BttReporte.setBackground(new java.awt.Color(255, 0, 0));
        BttReporte.setFont(new java.awt.Font("Lucida Handwriting", 1, 12)); // NOI18N
        BttReporte.setForeground(new java.awt.Color(255, 255, 255));
        BttReporte.setText("Reporte");

        bttSalir.setBackground(new java.awt.Color(255, 0, 0));
        bttSalir.setFont(new java.awt.Font("Lucida Handwriting", 1, 12)); // NOI18N
        bttSalir.setForeground(new java.awt.Color(255, 255, 255));
        bttSalir.setText("Salir");
        bttSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttSalirActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(255, 0, 0));
        jLabel1.setFont(new java.awt.Font("Lucida Handwriting", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\josue\\Pictures\\favicon (2).jpg")); // NOI18N
        jLabel1.setText("Libreria Menú");

        BttConectar.setBackground(new java.awt.Color(255, 0, 0));
        BttConectar.setFont(new java.awt.Font("Lucida Handwriting", 1, 12)); // NOI18N
        BttConectar.setForeground(new java.awt.Color(255, 255, 255));
        BttConectar.setText("Verificar Conexión");
        BttConectar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BttConectarActionPerformed(evt);
            }
        });

        BttInsertar.setBackground(new java.awt.Color(255, 0, 0));
        BttInsertar.setFont(new java.awt.Font("Lucida Handwriting", 1, 12)); // NOI18N
        BttInsertar.setForeground(new java.awt.Color(255, 255, 255));
        BttInsertar.setText("Nuevos");
        BttInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BttInsertarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(BttVender, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BttInsertar, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BttLista)
                    .addComponent(BttReporte, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(BttModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(BttConectar, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(bttSalir)
                .addGap(181, 181, 181))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BttInsertar, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BttLista, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BttReporte, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BttVender, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BttModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BttConectar, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(bttSalir)
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BttConectarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BttConectarActionPerformed
        // TODO add your handling code here:
        Conexion con= new Conexion();
        con.Conect();        
    }//GEN-LAST:event_BttConectarActionPerformed

    private void bttSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttSalirActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_bttSalirActionPerformed

    private void BttInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BttInsertarActionPerformed
        // TODO add your handling code here:
        MenuInsertar menu = new MenuInsertar(); 
        menu.setVisible(true);
        dispose();
    }//GEN-LAST:event_BttInsertarActionPerformed

    private void BttListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BttListaActionPerformed
        // TODO add your handling code here:
        MainListas menu = new MainListas(); 
        menu.setVisible(true);
        dispose();
    }//GEN-LAST:event_BttListaActionPerformed

    private void BttModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BttModificarActionPerformed
        // TODO add your handling code here:
        MenuModificar modi = new MenuModificar(); 
        modi.setVisible(true);
        dispose();
    }//GEN-LAST:event_BttModificarActionPerformed
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConexionFormulario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConexionFormulario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConexionFormulario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConexionFormulario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConexionFormulario().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BttConectar;
    private javax.swing.JButton BttInsertar;
    private javax.swing.JButton BttLista;
    private javax.swing.JButton BttModificar;
    private javax.swing.JButton BttReporte;
    private javax.swing.JButton BttVender;
    private javax.swing.JButton bttSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}